Open Day!

With this project I am realising a childhood dream. What if all the doors in the museum were suddenly open? What is behind it?

The Museum 1 and Museum 2 routes from the original game are copied as closely as possible.

Unfortunately, not all features are ready yet. You will certainly find a need for optimisation in the visiboxes and the rims are still missing. Don't worry, I will take care of the completion soon. If you want to support me, feel free to contact me :)

vonunwerth

You could help imprving this track by adding issues here: https://github.com/vonunwerth/museun